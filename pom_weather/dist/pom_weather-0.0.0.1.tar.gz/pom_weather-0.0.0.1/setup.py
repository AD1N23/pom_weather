from setuptools import setup

setup(name='pom_weather',
      version='0.0.0.1',
      description=':)',
      packages=['pom_weather'],
      author_email='mpomykin@mail.ru',
      zip_safe=False)
